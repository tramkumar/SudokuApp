# Sudoku Solver in C#, .NET MVC

I have used MVC pattern for exposing data and handling user response.
I have Implemented Dependecy Injection with IOC principles. Used Unity container tool.
I have Used C#, MVC, Javascript, XML, DI with IOC.

# Running

Requires .NET Framework/ Visual Studio to run this app. If nuget is not restored please restore nuget using manager nuget packages.

App is running in two way.
1. Play Game:
	- New Game to create sudoku and it will display the random number.
	- Back will go back to home page.
	- Solve will solve your sudoku solution

2. Setup Game:
	- Save will setup your sudoku puzzle and it will display to user we can customize our app.




