﻿using System;
using System.Linq;
using System.Web.Mvc;
using System.Web.Routing;
using Microsoft.Practices.Unity;

namespace Sudoku
{
	/// <summary>
	/// Description of UnityControllerFactory.
	/// </summary>
	public class UnityControllerFactory : DefaultControllerFactory
	{
		private readonly IUnityContainer container;
		
		public UnityControllerFactory(IUnityContainer unityContainer)
		{
			container = unityContainer;
		}
		
		protected override IController GetControllerInstance(RequestContext context, Type controllerType)
		{
			return (controllerType == null) ? null : container.Resolve(controllerType) as IController;
		}
		
		public override void ReleaseController(IController controller)
        {
            container.Teardown(controller);
            base.ReleaseController(controller);
        }
	}
}
