﻿using System;
using System.Web.Mvc;
using Sudoku.Model;
using Sudoku.ServiceLayer;

namespace Sudoku.Controllers
{
	/// <summary>
	/// Description of GameController.
	/// </summary>
	public class GameController : Controller
	{
		private IPuzzleLoader puzzleLoader;
		private IPuzzleSaver puzzleSaver;
		private IPuzzleService puzzleService;
		
		public GameController(IPuzzleLoader loader, IPuzzleSaver saver, IPuzzleService service)
		{
			puzzleLoader = loader;
			puzzleSaver = saver;
			puzzleService = service;
			
			// Load Constants into ViewData for partial view
			ViewData["BoardSize"] = Constants.BoardSize;
			ViewData["BlockSize"] = Constants.BlockSize;
		}
			
		public ActionResult NewGame()
		{
			SudokuBoard board = new SudokuBoard() { BoardList = puzzleService.SetupBoard() };
			int puzzleNumber;
			puzzleLoader.LoadNewPuzzle(board.BoardList, out puzzleNumber);
			board.BoardNumber = puzzleNumber;
            TempData["puzzleNumber"] = board.BoardNumber;
            return View("GameView", board);
		}

        public ActionResult SolveGame()
        {
            SudokuBoard board = new SudokuBoard() { BoardList = puzzleService.SetupBoard() };
            int boardNumber;
            boardNumber = Convert.ToInt32(TempData["puzzleNumber"]);
            puzzleLoader.LoadSolvePuzzle(boardNumber, board.BoardList);
            board.Status = puzzleService.GetPuzzleStatus(board.BoardList);
            return View("GameView", board);
        }
				
		public ActionResult SaveGame(SudokuBoard board)
		{
			puzzleSaver.SaveGame(board.BoardList, board.BoardNumber);
			board.Status = puzzleService.GetPuzzleStatus(board.BoardList);
			return View("GameView", board);
		}
	}
}