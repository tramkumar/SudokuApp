﻿using System;
using System.Web.Mvc;


namespace Sudoku.Controllers
{
	public class HomeController : Controller
	{
		public ActionResult Index()
		{
			return View();
		}
	}
}
