﻿using System;
using System.Collections.Generic;

namespace Sudoku.ServiceLayer
{
	/// <summary>
	/// Description of IPuzzleService.
	/// </summary>
	public interface IPuzzleService
	{
		List<Cell> SetupBoard();
		
		PuzzleStatus GetPuzzleStatus(List<Cell> cellList);
	}
}
