﻿using System;
using System.Collections.Generic;

namespace Sudoku.ServiceLayer
{
	/// <summary>
	/// Description of IPuzzleLoader.
	/// </summary>
	public interface IPuzzleLoader
	{
		void LoadNewPuzzle(List<Cell> cellList, out int puzzleNumber);
		
		void ReloadPuzzle(List<Cell> cellList, int puzzleNumber);

		void LoadSavedPuzzle(List<Cell> cellList, out int puzzleNumber);

        void LoadSolvePuzzle(int puzzleNumber, List<Cell> cellList);


    }
}
