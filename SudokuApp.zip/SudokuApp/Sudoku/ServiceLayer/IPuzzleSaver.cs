﻿using System;
using System.Collections.Generic;

namespace Sudoku.ServiceLayer
{
	/// <summary>
	/// Description of IPuzzleSaver.
	/// </summary>
	public interface IPuzzleSaver
	{
		void SaveGame(List<Cell> cellList, int puzzleNumber);
		
		void SavePuzzleSetup(List<Cell> cellList, ref int puzzleNumber);
	}
}
