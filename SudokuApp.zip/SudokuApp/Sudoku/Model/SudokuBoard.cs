﻿using System;
using System.Collections.Generic;
using System.Linq;
using Sudoku.ServiceLayer;

namespace Sudoku.Model
{
	/// <summary>
	/// A Sudoku board
	/// </summary>
	public class SudokuBoard
	{
		public List<Cell> BoardList { get; set; }
		public int BoardNumber { get; set; }
		public PuzzleStatus Status { get; set; }
		
		public SudokuBoard()
		{
			BoardList = new List<Cell>();
			Status = PuzzleStatus.Normal;
		}
	}
}
