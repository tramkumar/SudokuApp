﻿using System;
using System.Xml.Linq;

namespace Sudoku.DataLayer
{
	/// <summary>
	/// Description of IPuzzleRepository.
	/// </summary>
	public interface IPuzzleRepository
	{
		XDocument LoadPuzzleSetupXDoc();
		
		XDocument LoadSavedGameXDoc();
		
		void SavePuzzleSetupXDoc(XDocument xDoc);
		
		void SaveSavedGameXDoc(XDocument xDoc);
	}
}
